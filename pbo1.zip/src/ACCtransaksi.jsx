import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom"; // <--- Import Link di sini
import "./ACCtransaksi.css";

const ACCtransaksi = () => {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const dummyData = [ // <-- Tambahkan const dummyData di sini
      {
        name: "Kursi Lipat",
        contact: "08123456789",
        bank: "BCA",
        total: "Rp 500.000",
        status: "Paid"
      },
      {
        name: "Meja Belajar",
        contact: "08987654321",
        bank: "Mandiri",
        total: "Rp 750.000",
        status: "Not Paid"
      },
      {
        name: "Laptop Asus",
        contact: "08129876543",
        bank: "BRI",
        total: "Rp 8.500.000",
        status: "Pending"
      },
      {
        name: "Kipas Angin",
        contact: "08567891234",
        bank: "BNI",
        total: "Rp 350.000",
        status: "Paid"
      },
      {
        name: "Headphone Sony",
        contact: "08213456789",
        bank: "CIMB Niaga",
        total: "Rp 1.200.000",
        status: "Not Paid"
      }
    ];

    setTransactions(dummyData);
    setLoading(false);

    // // Ganti URL ini dengan endpoint API Anda
    // fetch("http://localhost:5000/api/transactions")
    //   .then((res) => res.json())
    //   .then((data) => {
    //     setTransactions(data);
    //     setLoading(false);
    //   })
    //   .catch((err) => {
    //     console.error("Error fetching data:", err);
    //     setLoading(false);
    //   });
  }, []);

  return (
    <div className="beranda-wrapper">
      <header>
        <h1 className="logo">EZBID</h1>
        <nav className="right-side">
          <div className="menu">
            <Link to="/beranda_login" className="menu-item">Beranda</Link>
            <Link to="#" className="menu-item">Titip Jual</Link>
            <Link to="/FAQ" className="menu-item">FAQ</Link>
          </div>
          <div className="logo">
            <Link to="#"><img src="/Bell.svg" alt="Notifikasi" className="notif" /></Link>
            <Link to="/ProfileSettings"><img src="/account_circle.svg" alt="Profil" className="profil" /></Link>
          </div>
        </nav>
        <div className="header-bg"></div>
        <div className="header-bg-black"></div>
      </header>

      <div className="acc-container">
        <div className="profile-page">
          <div className="sidebar">
            <Link to="/ProfileSettings" className="sidebar-item">Pengaturan Profil</Link>
            <Link to="/ACCtransaksi" className="sidebar-item">Transaksi</Link>
            <Link to="#" className="sidebar-item">Listing</Link>
            <Link to="#" className="sidebar-item">Logout</Link>
          </div>
        </div>

        <div className="content">
          <input className="search-bar" placeholder="Search..." />
          {loading ? (
            <p style={{ color: "white" }}>Loading...</p>
          ) : transactions.length === 0 ? (
            <p style={{ color: "white" }}>No transactions found.</p>
          ) : (
            <table className="transaction-table">
              <thead>
                <tr>
                  <th>Nama Barang</th>
                  <th>Kontak</th>
                  <th>Bank</th>
                  <th>Total Transaksi</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {transactions.map((item, idx) => (
                  <tr key={idx}>
                    <td>{item.name}</td>
                    <td>{item.contact}</td>
                    <td>{item.bank}</td>
                    <td>{item.total}</td>
                    <td className={`status ${item.status ? item.status.replace(/\s+/g, "-").toLowerCase() : ""}`}>
                      {item.s</div>tatus}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};

export default ACCtransaksi;
